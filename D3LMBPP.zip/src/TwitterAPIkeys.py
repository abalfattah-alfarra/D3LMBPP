import tweepy
import pandas as pd
from datetime import datetime, timedelta

# Twitter API keys
bearer_token = 'AAAAAAAAAAAAAAAAAAAAAFzexwEAAAAAMsbvk4jTP9zo%2FvtPc4BLi1EdEFc%3DGJamSnnwY5BgcGLrVLNG4AMdgrVWzJRZCaRuDfX6mrt3O7S0y4'
client = tweepy.Client(bearer_token)

# Search tweets function
def fetch_historical_tweets(query, start_date, end_date):
    all_tweets = []
    start = datetime.strptime(start_date, "%Y-%m-%d")
    end = datetime.strptime(end_date, "%Y-%m-%d")

    while start <= end:
        next_end = start + timedelta(days=6)  # Twitter allows up to 7-day search window
        if next_end > end:
            next_end = end
        
        print(f"Fetching tweets from {start} to {next_end}")
        tweets = client.search_all_tweets(
            query=query,
            start_time=start.strftime('%Y-%m-%dT00:00:00Z'),
            end_time=next_end.strftime('%Y-%m-%dT23:59:59Z'),
            max_results=100
        )
        
        if tweets.data:
            for tweet in tweets.data:
                all_tweets.append({
                    "text": tweet.text,
                    "created_at": tweet.created_at
                })
        
        start += timedelta(days=7)

    return pd.DataFrame(all_tweets)

# Fetch tweets from April 21, 2024, to January 5, 2025
bitcoin_tweets = fetch_historical_tweets("Bitcoin", "2024-04-21", "2025-01-05")

# Save to CSV
bitcoin_tweets.to_csv("bitcoin_tweets.csv", index=False)
print("Tweets saved to bitcoin_tweets.csv")
